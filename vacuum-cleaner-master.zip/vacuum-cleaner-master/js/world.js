// get cell


clean(row,col)

hasDirt(row,col)

navigatable(row,col)