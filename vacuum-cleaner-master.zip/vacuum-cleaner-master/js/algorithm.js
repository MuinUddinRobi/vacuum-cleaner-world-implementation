if( Me.dirty() ) {
	Me.suck();
} else {
	Me.moveRandom();
}